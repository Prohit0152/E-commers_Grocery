-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2023 at 10:47 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoping_jsp`
--

-- --------------------------------------------------------

--
-- Table structure for table `additems`
--

CREATE TABLE `additems` (
  `id` int(11) NOT NULL,
  `productname` text NOT NULL,
  `quantity` text NOT NULL,
  `price` text NOT NULL,
  `subject` text NOT NULL,
  `massage` text NOT NULL,
  `image1` text NOT NULL,
  `image2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `additems`
--

INSERT INTO `additems` (`id`, `productname`, `quantity`, `price`, `subject`, `massage`, `image1`, `image2`) VALUES
(1, 'Sugar', '11', '50', 'genuen ', 'good Quality', 'Sugar (1).jpg', 'Sugar (2).jpg'),
(2, 'Termaric', '10', '50', 'good Quality', 'genuen Product', 'Termaric (1).jpg', 'Termaric (2).jpg'),
(4, 'chilli', '10', '20', 'chilli genuen', 'no color added', 'Guntur-spicy-chilli-powder-pack.png', 'Guntur-spicy-chilli-powder-pack.png'),
(5, 'Fortune Oil', 'Very Good Branded', '850', 'genuene', 'good quality', 'grocery1 (7).png', 'grocery1 (7).png');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `email` text NOT NULL,
  `id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `status` text NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`email`, `id`, `qty`, `status`) VALUES
('prohitbagde372@gmail.com', 2, 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `seller_account`
--

CREATE TABLE `seller_account` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `phone` text NOT NULL,
  `gender` text NOT NULL,
  `address` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seller_account`
--

INSERT INTO `seller_account` (`id`, `name`, `email`, `username`, `password`, `phone`, `gender`, `address`, `status`) VALUES
(1, 'Prohit Bagde', 'prohitbagde372@gmail.com', 'Prohit1', 'Prohit1234', '8412053295', 'male', 'ngp', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_account`
--

CREATE TABLE `user_account` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `phone` text NOT NULL,
  `gender` text NOT NULL,
  `address` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_account`
--

INSERT INTO `user_account` (`id`, `name`, `email`, `username`, `password`, `phone`, `gender`, `address`, `status`) VALUES
(1, 'Prohit Bagde', 'prohitbagde372@gmail.com', 'prohit1', 'Prohit1234', '9284600152', 'male', 'nagpur', 1),
(2, 'Ht', 'sujal@gmail.com', 'Sujal1', 'Sujal1234', '7896541237', 'male', '', 1),
(3, 'Siddhant Sonwane', 'Siddhantsonwane544@gmail.com', 'Siddhantsonwane544@gmail.com', 'sidd@123', '9823193061', 'male', 'saoner', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `additems`
--
ALTER TABLE `additems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seller_account`
--
ALTER TABLE `seller_account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_account`
--
ALTER TABLE `user_account`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `additems`
--
ALTER TABLE `additems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `seller_account`
--
ALTER TABLE `seller_account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_account`
--
ALTER TABLE `user_account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
